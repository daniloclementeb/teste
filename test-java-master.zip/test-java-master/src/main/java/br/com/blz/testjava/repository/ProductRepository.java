package br.com.blz.testjava.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import br.com.blz.testjava.dto.ProductDTO;

@Component
@Scope("singleton")
public class ProductRepository {

	HashMap<Integer, ProductDTO> list;

	public ProductRepository() {
		list = new HashMap<Integer, ProductDTO>();
	}

	public ProductDTO getProduct(int sku) {
		return list.get(sku);
		/*return list.stream()
				.filter(i -> i.getSku() == sku)
				.findAny()
				.orElse(null);*/
	}

	public ProductDTO deleteProduct(int sku) {
		return list.remove(sku);
	}

	public ProductDTO createProduct(ProductDTO product) {
		return list.put(product.getSku(), product);
	}
}
