package br.com.blz.testjava.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import br.com.blz.testjava.dto.ProductDTO;
import br.com.blz.testjava.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	ProductRepository repository;

	public ProductDTO getProduct(int sku) {
		ProductDTO product = repository.getProduct(sku);
		calculateInventoryQuantity(product);
		isMarkatable(product);
		return product;
	}
	public ProductDTO removeProduct(int sku) {
		return repository.deleteProduct(sku);
	}

	public ProductDTO createProduct(ProductDTO product) {
		return repository.createProduct(product);
	}
	
	private void isMarkatable(ProductDTO product) {
		product.setIsMarketable(product.getInventory().getQuantity()>0?true:false);
	}
	
	private void calculateInventoryQuantity(ProductDTO product) {
		product.getInventory().setQuantity(
				product.getInventory()
				.getWarehouses()
				.stream().map(w-> w.getQuantity())
				.reduce(0, Integer::sum));
	}

}

