package br.com.blz.testjava.controller;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.blz.testjava.dto.ProductDTO;
import br.com.blz.testjava.service.ProductService;


@RestController
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@RequestMapping(path = "/product", method = RequestMethod.PUT)
	public @ResponseBody ProductDTO includeProduct(@RequestBody ProductDTO product,  HttpServletResponse response) {
		ProductDTO pd = service.createProduct(product);
		if (pd != null) {
			response.setStatus(HttpServletResponse.SC_CREATED);
		} else {
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		return pd;
	}
	
	@RequestMapping(path = "/product", method = RequestMethod.POST)
	public @ResponseBody ProductDTO updateProduct(@RequestBody ProductDTO product) {
		ProductDTO pd = service.createProduct(product);
		
		
		return pd;
	}
	
	@RequestMapping(path = "/product/{sku}", method = RequestMethod.DELETE)
	public @ResponseBody ProductDTO deleteProduct(@PathVariable int sku) {
		System.out.println(sku);
		return service.removeProduct(sku);
	}
	
	@RequestMapping(path = "/product/{sku}", method = RequestMethod.GET)
	public @ResponseBody ProductDTO getProduct(@PathVariable int sku) {
		System.out.println(sku);
		return service.getProduct(sku);
	}
}
